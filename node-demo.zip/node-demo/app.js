// const express = require('express');
// const app = express();
// const port = 3000;

// app.get('/', (req, res) => {
//     res.send('Hello World!')
// });

// app.listen(port, () => {
//     console.log(`Example app listening at http://localhost:${port}`)
// });



require('dotenv').config()
const express = require('express');
const bodyParser = require('body-parser');
const cookieSession = require('cookie-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect(process.env.YOUR_MONGO_URL, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define User schema and model
const UserSchema = new mongoose.Schema({
  username: String,
  password: String,
});
const User = mongoose.model('User', UserSchema);

// Configure Passport
passport.use(new LocalStrategy((username, password, done) => {
  User.findOne({ username }, (err, user) => {
    if (err) return done(err);
    if (!user || !user.password === password) return done(null, false);
    return done(null, user);
  });
}));
passport.serializeUser((user, done) => {
  done(null, user.id);
});
passport.deserializeUser((id, done) => {
  User.findById(id, (err, user) => {
    done(err, user);
  });
});

// Initialize Express
const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieSession({ keys: ['your_secret'] }));
app.use(passport.initialize());
app.use(passport.session());

// Routes
app.get('/', (req, res) => {
  res.render('index');
});
app.post('/register', (req, res) => {
  const newUser = new User({
    username: req.body.username,
    password: req.body.password,
  });
  newUser.save(() => res.redirect('/'));
});
app.post('/login', passport.authenticate('local'), (req, res) => {
  res.redirect('/dashboard');
});
app.get('/logout', (req, res) => {
  req.logOut();
  res.redirect('/');
});
app.get('/dashboard', ensureAuthenticated, (req, res) => {
  res.render('dashboard');
});

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/');
}

// Server setup
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server started on ${PORT}`));